var app = angular.module('App', ['ngRoute', 'ngStorage', 'ngMap', 'angular-md5']);
app.constant('globals', {
    mainPage: 'https://sportido.com'
});
        app.controller('SportidoCheckout', ["$scope", "CommonService", "$location", "$timeout", "$rootScope", "$localStorage", "$window", "md5",
 function ($scope, CommonService,$location,$timeout, $rootScope, $localStorage, $window, md5) {

  // $scope.usermobile = 8124438581;
    $rootScope.whatsappShare = function() {
        $rootScope.currentpage = $location.absUrl();
        $scope.sharewhatsappurl = "whatsapp://send?text=" + currentpage
    }
    $scope.init = function()
    {
      $window.scrollTo(0, 0);
      $scope.shareUrl = $location.absUrl();
       var temp1 = $location.absUrl().split('#')[0].split('&');
               new Fingerprint2().get(function(result, components){
  console.log(result); 
  console.log(components); 
  clevertap.profile.push({
 "Site": {
   "PlayerID": 42, // User's name
   "UID": result
 }


});
  $rootScope.UID = result;
   clevertap.event.push("Product Viewed");
});
       $rootScope.walletAmount = 0;
        for (var i = 0; i < temp1.length; i++) {
            
             if (temp1[i].indexOf("provider_id") != -1) {
                $rootScope.provider_id = temp1[i].split('=')[1];
             }
             else  if (temp1[i].indexOf("sub_type") != -1) {
                $rootScope.sub_type = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("sport_id") != -1) {
                $rootScope.sport_id = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("service_name") != -1) {
                $rootScope.provider_name = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("service_type") != -1) {
                $rootScope.service_type = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("slot_based") != -1) {
                $rootScope.slot_based = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("date") != -1) {
                $rootScope.selecteddateval = atob(temp1[i].split('=')[1]);
                $rootScope.selecteddatevaltemp = atob(temp1[i].split('=')[1]);
                $rootScope.selecteddateval = $rootScope.selecteddateval + " 00:00:00";

             }
             else  if (temp1[i].indexOf("provider_num") != -1) {
                $rootScope.providerNumber = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("slot") != -1) {
                $rootScope.selectedslot = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("package_id") != -1) {
                $rootScope.package_id = temp1[i].split('=')[1];
             }
             else  if (temp1[i].indexOf("By") != -1) {
                $rootScope.byLater = atob(temp1[i].split('=')[1]);
             }
              else  if (temp1[i].indexOf("price") != -1) {
                $rootScope.min_price = parseInt(atob(temp1[i].split('=')[1]));
             }
             else  if (temp1[i].indexOf("locality") != -1) {
                $rootScope.locality = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("selecteddayval") != -1) {
                $rootScope.selecteddayval = atob(temp1[i].split('=')[1]);
             }
             
             else  if (temp1[i].indexOf("discount") != -1) {
                $rootScope.discount = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("convenience") != -1) {
                $rootScope.convenience = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("commission") != -1) {
                $rootScope.commission = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("back") != -1) {
                $rootScope.cashback = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("package_name") != -1) {
                $rootScope.package_name = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("partner") != -1) {
                $scope.partner = atob(temp1[i].split('=')[1]);
             }
              else  if (temp1[i].indexOf("provider") != -1) {
                $scope.providern = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("service") != -1) {
                $scope.servicen = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("servicid") != -1) {
                $scope.service_id = atob(temp1[i].split('=')[1]);
             }
             
             
            }
        $rootScope.player_id = 42;
        $scope.useremail = $rootScope.useremail;
        $scope.username = $rootScope.username;
        $scope.usermobile = $rootScope.usermobile;
        $scope.month = $rootScope.MonthAsString($rootScope.selecteddateval.split("-")[1] - 1)
        $scope.day = $rootScope.selecteddateval.split("-")[2].split(" ")[0];
        $
  


        if($rootScope.byLater == true)
        {
          $scope.ByLater = true;
          $scope.apicall = true;
          $rootScope.package_id = 9999;
          // $rootScope.min_price = $localStorage.min_price;
          if($rootScope.selectedslot == undefined)
          {
            $rootScope.selectedslot = {};
          }
           clevertap.event.push("Selected_package", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $rootScope.package_name ,
  "Package_id":$rootScope.package_id,
  
});
          $rootScope.selectedslot.slot = "Default";
          $rootScope.selecteddateval = "2018-12-15 00:00:00";
          $rootScope.slot_based = 1;
          $scope.venueCash = "0,0" ;
          $scope.checkoutdata = {};
          $scope.checkoutdata.data = {};
          $rootScope.min_price = $rootScope.min_price;
          $scope.checkoutdata.data.total = $rootScope.min_price;
          $scope.payProvider = $rootScope.min_price;
            $scope.venuePay = $rootScope.min_price - $rootScope.walletAmount;;
            $rootScope.service_type = 1;
        }
        else{
          $scope.ByLater = false;
       

        // var req = "subtype=" + $scope.sub_type + "&paytm_transaction_id=0&player_id=" + $scope.sport_id  + "&player_name=" + $scope.username + "&player_email=" + $scope.useremail + "&player_mobile=" + $scope.usermobile + "&provider_id=" + $scope.provider_id + "&provider_name=" + $scope.provider_name + "&service_type=1&sport_id=4&package_id=5365&slot=Monthly&booking_date=2017-11-16&cost_shown=2500&cost_paid=2400&payment_status=2&notes_from_customer=100&pay_provider=2250&venue_pay=0&provider_contact_number=8860840439&slot_based=0&confirmed=2&transaction_date=2017-11-15 20:24:57&venue_cashback=10,0&wallet_use=100&wallet_balance=100.0"
        $scope.req = "player_id=" + $rootScope.player_id +"&provider_id=" + $rootScope.provider_id;
        var data = CommonService.checkoutapi($scope);
        data.then(function (dt) {
            console.log(dt);
            $scope.checkoutdata = dt.data;
            // $scope.partner = $localStorage.partner;
            // $rootScope.service_type = $scope.checkoutdata.data.service_type;
            $scope.apicall = true;
            $localStorage.service_type = $rootScope.service_type;
            $scope.sportidoPercent = angular.copy($rootScope.convenience);
            $scope.discountPercent = angular.copy($rootScope.discount);
             clevertap.event.push("Selected_package", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $rootScope.package_name ,
  "Package_id":$rootScope.package_id,
  
});
            
            $scope.venueCash = $scope.sportidoPercent + "," +  $scope.discountPercent ;
          
            // $rootScope.convenience = ($rootScope.min_price * parseInt(parseInt($rootScope.convenience)))/100;
            $scope.discountprice = ($rootScope.min_price * parseInt($rootScope.discount))/100;
            $rootScope.discount = $scope.discountprice;
            $scope.checkoutdata.data.total = $rootScope.min_price + parseFloat($rootScope.convenience) - parseFloat($scope.discountprice);
            $scope.payProvider = $rootScope.min_price - parseInt($rootScope.convenience);
            $scope.venuePay = $rootScope.min_price - parseInt($scope.discountprice) - $rootScope.walletAmount;
            
        });
         }
    }

    function handleResponse(res) {
      console.log("himanshu")
                if (typeof res != 'undefined' && typeof res.paymentMethod != 'undefined' && typeof res.paymentMethod.paymentTransaction != 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode != 'undefined' && res.paymentMethod.paymentTransaction.statusCode == '0300') {
                    // success code
                } else {
                    // error code
                }
            };

    $rootScope.redirect = function(path) {
        if(path == "Home")
        {
          $window.location.href ="home.html";
        }
        else if(path == "Listing")
        {
          $window.location.href = "listing.html?sub_type=" + btoa($rootScope.sub_type);
        }
        else if(path == "Profile")
        {
          $window.location.href = "profile.html?provider_id=" + $rootScope.provider_id + "&sub_type=" + btoa($rootScope.sub_type) + "&provider=" + btoa($scope.providern) + "&service=" + btoa($scope.servicen) + "&service_id=" + btoa($scope.service_id);
   
        }
       
    }

     function getDateTime() {
    var now     = new Date(); 
    var year    = now.getFullYear();
    var month   = now.getMonth()+1; 
    var day     = now.getDate();
    var hour    = now.getHours();
    var minute  = now.getMinutes();
    var second  = now.getSeconds(); 
    if(month.toString().length == 1) {
        var month = '0'+month;
    }
    if(day.toString().length == 1) {
        var day = '0'+day;
    }   
    if(hour.toString().length == 1) {
        var hour = '0'+hour;
    }
    if(minute.toString().length == 1) {
        var minute = '0'+minute;
    }
    if(second.toString().length == 1) {
        var second = '0'+second;
    }   
    var dateTime = year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;   
     return dateTime;
}

    $scope.postPay = function()
    {
      console.log("hi himanshu welcome back")
    }

    $rootScope.GetDates = function(startDate, daysToAdd) {
        var aryDates = [];
        for (var i = 0; i <= daysToAdd; i++) {
            var currentDate = new Date();
            currentDate.setDate(startDate.getDate() + i);
            aryDates.push($rootScope.DayAsString(currentDate.getDay()) + ", " + currentDate.getDate() + ", " + currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1) + "-" + currentDate.getDate())
        }
        return aryDates
    }
    $rootScope.MonthAsString = function(monthIndex) {
        var d = new Date();
        var month = new Array();
        month[0] = "January";
        month[1] = "February";
        month[2] = "March";
        month[3] = "April";
        month[4] = "May";
        month[5] = "June";
        month[6] = "July";
        month[7] = "August";
        month[8] = "September";
        month[9] = "October";
        month[10] = "November";
        month[11] = "December";
        return month[monthIndex]
    }
    $rootScope.DayAsString = function(dayIndex) {
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        return weekdays[dayIndex]
    }
    $scope.prePay = function()
    {
       // var configJson = {
       //              'tarCall': false,
       //              'features': {
       //                  'showPGResponseMsg': true,
       //                  'enableNewWindowFlow': true
       //              },
       //              'consumerData': {
       //                  'deviceId': 'WEBSH2', //possible values 'WEBSH1', 'WEBSH2' and 'WEBMD5'
       //                  'token': "ca25c3ecb179f82d06059d693b6ad4ad901671ea09e1bdec318d908cead1ed1eab3ca1265e833f98614ef92691d125d9d6eb92599e900c20eb593e95afbeedc5",
       //                  'returnUrl': 'http://ec2-34-193-7-167.compute-1.amazonaws.com/web/payment',
       //                  'responseHandler': handleResponse,
       //                  'paymentMode': 'all',
       //                  'merchantId': 'T142800',
       //                  'consumerId': $rootScope.player_id, //playerid
       //                  'consumerMobileNo': $scope.usermobile,
       //                  'consumerEmailId': $scope.useremail,
       //                  'txnId': $scope.payout.booking_id,   //Unique merchant transaction ID
       //                  'items': [{
       //                      'itemId': $rootScope.sub_type,
       //                      'amount': $scope.costPaid,
       //                      'comAmt': '0'
       //                  }],
       //                  'customStyle': {
       //                      'PRIMARY_COLOR_CODE': '#3977b7',
       //                      'SECONDARY_COLOR_CODE': '#FFFFFF',
       //                      'BUTTON_COLOR_CODE_1': '#1969bb',
       //                      'BUTTON_COLOR_CODE_2': '#FFFFFF'
       //                  }
       //              }
       //          };
       var token = "L201139|" + $scope.payout.booking_id + "|" + $scope.checkoutdata.data.total + "||" + $scope.player_id 
       + "|" + $scope.usermobile + "|" + $scope.useremail + "||||||||||7691567138MMOBPX";
       token = md5.createHash(token);
        var configJson = {
                    'tarCall': false,
                    'features': {
                        'showPGResponseMsg': true,
                        'enableNewWindowFlow': true
                    },

                    'consumerData': {
                        'deviceId': 'WEBMD5',   //possible values 'WEBSH1', 'WEBSH2' and 'WEBMD5'
                        'token': token,
                        'returnUrl': 'http://ec2-34-193-7-167.compute-1.amazonaws.com/web/payment',
                        'responseHandler': handleResponse,
                        'paymentMode': 'all',
                        'merchantId': 'L201139',
                        'consumerId': $rootScope.player_id,
                        'consumerMobileNo': $scope.usermobile,
                        'consumerEmailId':$scope.useremail,
                        'txnId': $scope.payout.booking_id,   //Unique merchant transaction ID
                        'items': [{
                            'itemId': "FIRST",
                            'amount': $scope.costPaid,
                            'comAmt': '0'
                        }],
                        'customStyle': {
                            'PRIMARY_COLOR_CODE': '#3977b7',
                            'SECONDARY_COLOR_CODE': '#FFFFFF',
                            'BUTTON_COLOR_CODE_1': '#1969bb',
                            'BUTTON_COLOR_CODE_2': '#FFFFFF'
                        }
                    }
                };

                $rootScope.configJson = configJson;
                $localStorage.configJson =configJson;
                clevertap.event.push("Selected_paynow", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $rootScope.package_name ,
  "Package_id":$rootScope.package_id,
  "Amount": $scope.checkoutdata.data.total,
  
});
                $.pnCheckout(configJson);
                if(configJson.features.enableNewWindowFlow){
                    $(document).data('pnCheckout').openNewWindow();
                }
    }

    
    $scope.pay = function(id)
    {

      var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        var reg1 = /^([0|\+[0-9]{1,5})?([1-9][0-9]{9})$/;
        var reg2 = /^[a-zA-Z\s]*$/;
         if ( ( $scope.username != undefined ) && ( reg2.test( $scope.username ) ) && $scope.useremail != undefined && $scope.useremail.length != 4 && reg.test( $scope.useremail )  && $scope.usermobile != undefined && $scope.usermobile.toString().length == 10 && reg1.test( $scope.usermobile )) {

            
        $scope.dateTimeVal = getDateTime();
        $scope.nameerror = false;
        $scope.emailerror = false;
        $scope.mobileerror = false;

          gtag('event', 'conversion', {'send_to': 'AW-805765541/VACNCLr28oIBEKWDnIAD'});
        if(id == 1 || id ==3)
        {
            $scope.costPaid = $scope.checkoutdata.data.total;
            $scope.payStatus = 4;
            $scope.showOnlinePay = true;
            $scope.confirmedVal = 2;
            if($rootScope.walletAmount >$scope.checkoutdata.data.total)
            {
                $scope.walletUsed = $scope.checkoutdata.data.total;
            }
            else{
                $scope.walletUsed = $rootScope.walletAmount;
            }
        }
        else{
            
            $scope.costPaid = 0;
            $scope.payStatus = 3;
            $scope.confirmedVal = 0;
            $scope.walletUsed = 0;

        }
$rootScope.bookrequest = "payment_transaction_id=Null&player_id="  + $rootScope.player_id  + "&name=" + $scope.username + "&mobile=" + $scope.usermobile
        + "&package_id=" + $rootScope.package_id + "&book_date=" + $rootScope.selecteddateval + "&cost_shown=" + $rootScope.min_price + "&cost_paid=" +  $scope.costPaid  + "&payment_status=" + $scope.payStatus + "&transaction_date=" + $scope.dateTimeVal + "&commission=" + $rootScope.convenience + "&cashback_applied=" + $scope.venueCash  + "&convenience_fees=" + $rootScope.convenience + "&discount=" + $scope.discountprice + "&wallet_applied=" + $scope.walletUsed + "&source=Website&slot_names=10:00-11:00";
     
        // $rootScope.bookrequest = "subtype=" + $rootScope.sub_type + "&paytm_transaction_id=0&player_id=" + $rootScope.player_id + "&player_name=" + $scope.username + "&player_email=" + $scope.useremail + "&player_mobile=" + $scope.usermobile + "&provider_id=" + $rootScope.provider_id + "&provider_name=" + $rootScope.provider_name + "&service_type=" + $rootScope.service_type + "&sport_id=" + $rootScope.sport_id + "&package_id=" + $rootScope.package_id + "&slot=" + "10:00-11:00" + "&booking_date=" + $rootScope.selecteddateval + "&cost_shown=" + $rootScope.min_price + "&cost_paid=" + $scope.costPaid + "&payment_status=" + $scope.payStatus + "&notes_from_customer=" + $scope.walletUsed  + "&pay_provider=" + $scope.payProvider + "&venue_pay=" + $scope.venuePay + "&provider_contact_number=" + $rootScope.providerNumber + "&slot_based=" + "1" + "&confirmed=" + $scope.confirmedVal + "&transaction_date=" + $scope.dateTimeVal + "&venue_cashback=" + $scope.venueCash + "&wallet_use=" + $scope.walletUsed  + "&wallet_balance=" + $rootScope.walletAmount;
      
        // $rootScope.bookrequest =  "&payment_transaction_id=0&player_id=" + $rootScope.player_id + "&package_id=" + $rootScope.package_id + "&discount=" + $scope.discountprice + "&book_date=" + $rootScope.selecteddateval + "&cost_shown=" + $rootScope.min_price + "&cost_paid=" + $scope.costPaid + "&payment_status=" + $scope.payStatus + "&notes_from_customer=" + $scope.walletUsed  + "&pay_provider=" + $scope.payProvider +  "&transaction_date=" + $scope.dateTimeVal + "&cashback_applied=" + $scope.venueCash + "&wallet_applied=" + $scope.walletUsed + "&convenience_fees=" + $rootScope.convenience + "&commission=" + $rootScope.convenience;
        $localStorage.bookrequest = $rootScope.bookrequest;
        console.log($rootScope);
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        var reg1 = /^([0|\+[0-9]{1,5})?([1-9][0-9]{9})$/;
        var reg2 = /^[a-zA-Z\s]*$/;
      
               
                $rootScope.username = $scope.username;
                if(id == 2)
                {
                     $scope.showVenuePay = true;
                }
              
                var data = CommonService.payapi($scope);
                    data.then(function (dt) {
                    console.log(dt);
                    $scope.payout = dt.data;
                    // if($scope.payout.success ==1)
                    // {$scope.successpop = true;

                    // }
                    if(id == 1)
                    {$scope.prePay();}
                    else
                    {
                        $rootScope.payout = $scope.payout;
                        $localStorage.payout = $rootScope.payout;
                        $scope.showVenuePay = false;
                          clevertap.event.push("Selected_payatvenue", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $rootScope.package_name ,
  "Package_id":$rootScope.package_id,
  "Amount": $scope.checkoutdata.data.total,
  
});
                       // $location.path("/Thanks");

                       if(id == 2)
                       {
                        $window.location.href ="thanks.html?booking_id=" + $rootScope.payout.booking_id + "&mode=" + btoa(2);
                       }
                       else
                      {

                       $window.location.href ="thanks.html?booking_id=" + $rootScope.payout.booking_id;
                      }
                    }
                    
                });
            
               

         }
              else { 
                if(!(( $scope.username != undefined ) && ( reg2.test( $scope.username ) )))
                   {
                       $scope.nameerror = true;
                   }
                   if(!($scope.useremail != undefined && $scope.useremail.length != 4 && reg.test( $scope.useremail )))
                   {
                       $scope.emailerror = true;
                   }
                   if(!($scope.usermobile != undefined && $scope.usermobile.toString().length == 10 && reg1.test( $scope.usermobile )))
                   {
                       $scope.mobileerror = true;
                   }
            }
          
    }


 }]);


app.directive('focusMe', ['$timeout', '$parse', function($timeout, $parse) {
    return {
        link: function(scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function(value) {
                console.log('value=', value);
                if (value === !0) {
                    $timeout(function() {
                        element[0].focus()
                    })
                }
            });
            element.bind('blur', function() {
                console.log('blur');
                scope.$apply(model.assign(scope, !1))
            })
        }
    }
}]);
app.directive('whatsApp', function() {
    return {
        link: function(scope, elem, $attr) {
            elem.on('click', function() {
                var text = $attr.text;
                var url = $attr.whatsApp;
                var message = encodeURIComponent(text) + "  " + encodeURIComponent(url);
                var whatsapp_url = "whatsapp://send?text=" + message;
                window.location.href = whatsapp_url
            })
        }
    }
})

app.directive('onlyLettersInput', onlyLettersInput);

function onlyLettersInput() {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z\s]/g, '');
                //console.log(transformedInput)
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
};


app.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                     text = text.toString();
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});