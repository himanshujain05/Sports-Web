var app = angular.module('App', ['ngRoute', 'ngStorage', 'ngMap', 'angular-md5']);
app.constant('globals', {
    mainPage: 'https://sportido.com'
});

        app.controller('SportidoProfile', ["$scope", "CommonService", "$location", "$timeout", "$rootScope", "$localStorage", "$window", "NgMap",
 function ($scope, CommonService,$location,$timeout, $rootScope, $localStorage, $window, NgMap) {

  $rootScope.whatsappShare = function() {
        $rootScope.currentpage = $location.absUrl();
        $scope.sharewhatsappurl = "whatsapp://send?text=" + currentpage
    }
    $scope.init = function()
    {
      $scope.readmore = true;
        $window.scrollTo(0, 0);
        $scope.shareUrl = $location.absUrl();
                new Fingerprint2().get(function(result, components){
  console.log(result); 
  console.log(components); 
  clevertap.profile.push({
 "Site": {
   "PlayerID": 42, // User's name
   "UID": result
 }


});
  $rootScope.UID = result;
   clevertap.event.push("Product Viewed");
});
        var temp1 = $location.absUrl().split('#')[0].split('&');
        
         for (var i = 0; i < temp1.length; i++) {
            
             if (temp1[i].indexOf("provider_id") != -1) {
                $rootScope.provider_id = temp1[i].split('=')[1];
             }
             else  if (temp1[i].indexOf("sub_type") != -1) {
                $rootScope.sub_type = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("service_id") != -1) {
                $rootScope.service_id = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("provider") != -1) {
                $scope.providern = atob(temp1[i].split('=')[1]);
             }
             else  if (temp1[i].indexOf("service") != -1) {
                $scope.servicen = atob(temp1[i].split('=')[1]);
             }
             
            }

            $scope.titlebind = $scope.providern + ", " + $scope.servicen;
        $rootScope.player_id = 42;
        $scope.req = "player_id=" + $rootScope.player_id + "&loc_lat=28.463783&loc_long=77.032344" +"&provider_id=" + $rootScope.provider_id + "&service_id=" + $rootScope.service_id  ;
        var data1 = CommonService.getProfileapi2($scope);
        data1.then(function (dt1) {
          $scope.package_details = dt1.data.data;
          for(var i=0;i<$scope.package_details.length;i++)
          {
            $scope.package_details[i].desid = true;
            if($scope.package_details[i].discount >0)
            {
              $scope.package_details[i].discounted = $scope.package_details[i].price - (($scope.package_details[i].price * $scope.package_details[i].discount)/100);
            }
          }
        });


        var data = CommonService.getProfileapi($scope);
        data.then(function (dt) {
            console.log(dt);
            
            $scope.profileListing = dt.data;
            $rootScope.providerNumber = $scope.profileListing.data.provider_number;
            $localStorage.providerNumber = $rootScope.providerNumber;
            $scope.partner = $scope.profileListing.data.is_partner;
            // $scope.package_details = dt.data.package_details;
             $rootScope.locality = $scope.profileListing.data.provider_locality;
            $localStorage.locality = $rootScope.locality;
            
            // for(var i=0;i<$scope.profileListing.data.services.length;i++)
            // {
            //     if(i>0)
            //     {
            //         $scope.profileServices = $scope.profileServices + ", " + $scope.profileListing.data.services[i].service_name;
            //         if($scope.profileLowCost > $scope.profileListing.data.services[i].service_lowest_cost)
            //         {
            //             $scope.profileLowCost = $scope.profileListing.data.services[i].service_lowest_cost
            //         }
            //     }
            //     else
            //     {
            //         $scope.profileServices = $scope.profileListing.data.services[i].service_name;
            //         $scope.profileLowCost = $scope.profileListing.data.services[i].service_lowest_cost;
            //     }
            // }
        });
    }

       $rootScope.redirect = function(path) {
        if(path == "Home")
        {
          $window.location.href ="home.html";
        }
        if(path == "Listing")
        {
          $window.location.href = "listing.html?sub_type=" + btoa($rootScope.sub_type);
        }
       
    }


   $scope.apicall = function()
   {
    $scope.bookedslots = [];
        $scope.availableslots = [];
        var data = CommonService.getslotapi($scope);
        data.then(function (dt) {
            console.log(dt);
            $scope.slotsdata = dt.data;
        
        $rootScope.locality = $scope.slotsdata.data[0].locality;
        $localStorage.locality = $rootScope.locality;

       $scope.bookedslots = [];
        $scope.availableslots = [];
        if($scope.slotsdata.data[0].day != undefined)
        {
            $scope.noSlots = false;
        for(var i=0;i<$scope.slotsdata.data[0].day.slots.length;i++)
        {
            if($scope.slotsdata.data[0].day.slots[i].booked_slots != undefined && $scope.slotsdata.data[0].day.slots[i].package_id == $scope.packageid1)
            {
                for(j=0;j<$scope.slotsdata.data[0].day.slots[i].booked_slots.length;j++)
                {
                    $scope.bookedslots.push({slot:$scope.slotsdata.data[0].day.slots[i].booked_slots[j]});
                }

            }
            if($scope.slotsdata.data[0].day.slots[i].slots != undefined && $scope.slotsdata.data[0].day.slots[i].package_id == $scope.packageid1)
            {
                for(k=0;k<$scope.slotsdata.data[0].day.slots[i].slots.length;k++)
                {
                    $scope.availableslots.push({slot:$scope.slotsdata.data[0].day.slots[i].slots[k], class:"", id:k, package:$scope.slotsdata.data[0].day.slots[i].package_id,  slot_based:$scope.slotsdata.data[0].day.slots[i].slot_based});
                }
            }
        }
    }
    else
    {
        $scope.noSlots = true;
    }

        $scope.callbck = true;
        });
   }

   $rootScope.GetDates = function(startDate, daysToAdd) {
        var aryDates = [];
        for (var i = 0; i <= daysToAdd; i++) {
            var currentDate = new Date();
            currentDate.setDate(startDate.getDate() + i);
            aryDates.push($rootScope.DayAsString(currentDate.getDay()) + ", " + currentDate.getDate() + ", " + currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1) + "-" + currentDate.getDate())
        }
        return aryDates
    }
    $rootScope.MonthAsString = function(monthIndex) {
        var d = new Date();
        var month = new Array();
        month[0] = "January";
        month[1] = "February";
        month[2] = "March";
        month[3] = "April";
        month[4] = "May";
        month[5] = "June";
        month[6] = "July";
        month[7] = "August";
        month[8] = "September";
        month[9] = "October";
        month[10] = "November";
        month[11] = "December";
        return month[monthIndex]
    }
    $rootScope.DayAsString = function(dayIndex) {
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        return weekdays[dayIndex]
    }

   $scope.bookslot1 = function()
   {
    $window.location.href = "checkout.html?provider_id=" + $rootScope.provider_id + "&sub_type=" + btoa($rootScope.sub_type) + "&package_id=" + $rootScope.package_id + "&slot_based=" + btoa($rootScope.slot_based) + "&back=" + btoa($scope.cashback) + "&commission=" + btoa($scope.commission)  + "&convenience=" + btoa($scope.convenience_fees)  + "&discount=" + btoa($scope.discount) + "&price=" + btoa($scope.price)  + "&provider_num=" + btoa($rootScope.providerNumber)  + "&date=" + btoa($rootScope.selecteddateval) + "&slot=" + btoa($rootScope.selectedslot.slot) + "&service_type=" + btoa($rootScope.service_type) + "&service_name=" + btoa($scope.profileListing.data.name) + "&sport_id=" + btoa($rootScope.sport_id) + "&locality=" + btoa($rootScope.locality) + "&selecteddayval=" + btoa($rootScope.selecteddayval)   + "&package_name=" + btoa($scope.buyitem.package_name)  + "&partner=" + btoa($scope.profileListing.data.payment_type) + "&provider=" + btoa($scope.providern) + "&service=" + btoa($scope.servicen) + "&servicid=" + btoa($rootScope.service_id) ;
   $scope.showslotspop = false;
    // $scope.showuserinfo = true;
   }

   $scope.showPlan = function(id)
   {
        if(id ==1)
        {
            $scope.askPlan = false;
            $scope.askSlot = true;
            $scope.showDate = true;
            $localStorage.byLater = false;
            $scope.selecteddayval = $scope.selecteddayval.toLowerCase();

              clevertap.event.push("Clicked_decide_now", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $scope.package_name ,
});
            $scope.apicall();
        }
        else{

  clevertap.event.push("Clicked_decide_later", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $scope.package_name ,
});
            $scope.selecteddateval = " ";
            $scope.selecteddayval = " ";
            $localStorage.byLater = true;

            var data = CommonService.decidelater($scope);
        data.then(function (dt) {
            console.log(dt);
            $scope.slotslaterdata = dt.data;
            $rootScope.min_price =  $scope.price;
            $localStorage.min_price = $rootScope.min_price;
            $rootScope.package_id = 999999;
                $rootScope.service_name = $scope.profileListing.data.service_name;
                $localStorage.package_id = $rootScope.package_id;
                $localStorage.service_name = $rootScope.service_name;

                // $location.path("/Checkout");
                $window.location.href = "checkout.html?provider_id=" + $rootScope.provider_id +  "&sub_type=" + btoa($rootScope.sub_type) + "&package_id=" + $rootScope.package_id + "&slot_based=" + btoa($rootScope.slot_based) + "&back=" + btoa($scope.cashback) + "&commission=" + btoa($scope.commission)  + "&convenience=" + btoa($scope.convenience_fees)  + "&discount=" + btoa($scope.discount) + "&price=" + btoa($scope.price)  + "&provider_num=" + btoa($rootScope.providerNumber)  + "&date=" + btoa($rootScope.selecteddateval) + "&service_type=" + btoa($rootScope.service_type) + "&provider_name=" + btoa($rootScope.service_name) + "&sport_id=" + btoa($rootScope.sport_id) + "&By=" + btoa($localStorage.byLater) + "&price=" + btoa($rootScope.min_price) + "&locality=" + btoa($rootScope.locality) + "&selecteddayval=" + btoa($rootScope.selecteddayval) + "&service_name=" + btoa($scope.profileListing.data.name) + "&package_name=" + btoa($scope.buyitem.package_name) + "&partner=" + btoa($scope.profileListing.data.payment_type) + "&provider=" + btoa($scope.providern) + "&service=" + btoa($scope.servicen) + "&servicid=" + btoa($rootScope.service_id) ;
                 $scope.showslotspop = false;
    // $scope.showuserinfo = true;
            // if($scope.slotslaterdata.max_price != $scope.slotslaterdata.min_price )
            // {
                
            // }
            // else{
            //     $scope.askPlan = false;
            // $scope.askSlot0 = true;
            // $scope.showDate = false;
            // $rootScope.package_id = 999999;
            //     $rootScope.service_name = $scope.profileListing.data.service_name;
            //     $localStorage.package_id = $rootScope.package_id;
            //     $localStorage.service_name = $rootScope.service_name;

            // }

        })
        }
   }

    $scope.buy = function(item)
    {
        $scope.cashback = item.cashback;
        $scope.commission = item.commission;
        $scope.convenience_fees = item.convenience_fees;
        $scope.discount = item.discount;
        $scope.price = item.price;
        $scope.buyitem = item;
        $scope.subtype = item.subtype;
        $scope.package_name = item.package_name;
        $rootScope.package_name = $scope.package_name;
        $localStorage.package_name = $scope.package_name;
        $scope.a1 = false;
        $scope.a2 = false;
        $scope.packageid1 = item.package_id;
        clevertap.event.push("Clicked_package", {
  "Provider_id":$rootScope.provider_id,
  "Package_name": $scope.package_name ,
});
        var startDate = new Date();
         // $scope.askSlot = false;
         // $scope.askPlan = true;
         // $scope.showuserinfo = true;
         
        var aryDates = $rootScope.GetDates(startDate, 7);
        $scope.days = [];

        $scope.showslotspop = true;
        for(var i=0;i<aryDates.length;i++)
        {
            var temp = aryDates[i].split(",");
            if(i==0)
            $scope.days.push({day:temp[0], date:temp[1], dob:temp[2], class:"dateactive"});
            else
            $scope.days.push({day:temp[0], date:temp[1], dob:temp[2], class:""});   
        }

        $scope.selecteddayval = $scope.days[0].day;
        $scope.selecteddateval = $scope.days[0].dob.replace(" ", "");
        $rootScope.selecteddayval = $scope.selecteddayval;
        $rootScope.selecteddateval = $scope.selecteddateval;
        $localStorage.selecteddayval = $rootScope.selecteddayval;
        $localStorage.selecteddateval = $rootScope.selecteddateval;
        $scope.slotApi($scope.days[0].dob, $scope.days[0].day, "May");
        // $scope.showPlan(1);
        // $scope.slotsdata = {"data": [{"distance": 40.53383119122056, "provider_id": 1986, "name": "Spuddy Badminton Academy", "locality": "Sector 48 Gurgaon", "mobile": "8860840439", "min_price": 300, "is_open": 1, "is_partner": 1, "day": {"slots": [{"booked_slots": ["02:00", "01:00"], "slots": ["05:00", "10:00", "11:00", "22:00"], "package_id": 5361, "slot_based": 0}, {"booked_slots": [], "slots": ["06:00", "07:00", "08:00", "09:00", "19:00", "20:00", "21:00"], "package_id": 5362, "slot_based": 0}, {"booked_slots": [], "slots": ["12:00", "13:00", "14:00", "15:00"], "package_id": 5363, "slot_based": 0}]}}], "success": 1};
        if($scope.profileListing.data.payment_type ==1)
              {$scope.askSlot = false;
                            $scope.showuserinfo = false;
                       $scope.showPlan(1);}
              else
              {
                // $location.path("/Request");
                $window.location.href = "checkout.html?provider_id=" + $rootScope.provider_id + "&sub_type=" + btoa($rootScope.sub_type) + "&package_id=" + $scope.buyitem.package_id + "&slot_based=" + btoa($rootScope.slot_based) + "&back=" + btoa($scope.cashback) + "&commission=" + btoa($scope.commission)  + "&convenience=" + btoa($scope.convenience_fees)  + "&discount=" + btoa($scope.discount) + "&price=" + btoa($scope.price)  + "&provider_num=" + btoa($rootScope.providerNumber)  + "&date=" + btoa($rootScope.selecteddateval)  + "&service_type=" + btoa($rootScope.service_type) + "&service_name=" + btoa($scope.profileListing.data.name) + "&sport_id=" + btoa($rootScope.sport_id) + "&locality=" + btoa($rootScope.locality) + "&selecteddayval=" + btoa($rootScope.selecteddayval)   + "&package_name=" + btoa($scope.buyitem.package_name)  + "&partner=" + btoa($scope.profileListing.data.payment_type) + "&provider=" + btoa($scope.providern) + "&service=" + btoa($scope.servicen) + "&servicid=" + btoa($rootScope.service_id) ;
                // $window.location.href ="booking.html?booking_id=";
              }
    }


    $scope.scrollD = function()
    {
        $window.scrollTo(200, 400);
    }

    $scope.slotApi = function(date, day, month)
    {

        var temdate1 = date.split("-");
        var temdate = temdate1[2] + "-" +  temdate1[1] + "-" + temdate1[0].trim();
         var data = CommonService.getSlotData($scope, temdate, day, month);
         $scope.selectedslottemp = undefined;
         $scope.errorslotbook = undefined;
         $scope.availableslotsdata = [];
        data.then(function (result) {
             if(result.data.data != undefined)
            {
              if(result.data.data.length > 0)
              {if(result.data.data[0].slot_name != undefined && result.data.data[0].slot_name != "")
                           { $scope.availableslotsdata = result.data.data;
                                            for(var i=0;i<$scope.availableslotsdata.length;i++)
                                   {
                                       $scope.availableslotsdata[i].class="";
                                  
                                   }}
                                   else{
                                    $scope.availableslotsdata = [];
                                   }}
   
       
            }
        });
    } 



    $scope.selectedday = function(item, index)
   {
        for(var i=0;i<$scope.days.length;i++)
        {
            $scope.days[i].class="";
        }
        for(var i=0;i<$scope.availableslots.length;i++)
        {
            $scope.availableslots[i].class="";
       
        }
        $scope.days[index].class="dateactive";
        $scope.selecteddayval = item.day;
        $scope.showbook = false;
        $scope.selecteddateval = item.dob.replace(" ", "");;
        $rootScope.selecteddayval = item.day;
        $rootScope.selecteddateval = $scope.selecteddateval;
        $localStorage.selecteddayval = $rootScope.selecteddayval;
        $localStorage.selecteddateval = $rootScope.selecteddateval;
        $scope.apicall();
        $scope.slotApi(item.dob, item.day, "May");

   }

   $scope.selectedtimeslottemp  = function(item, index)
   {
        for(var i=0;i<$scope.availableslotsdata.length;i++)
        {
            $scope.availableslotsdata[i].class="";
            if($scope.availableslotsdata[i] == item)
            {
                $scope.availableslotsdata[i].class="green";
            }
        }
        $scope.selectedslottemp = item;
        $scope.errorslotbook = false;
        $rootScope.selectedslot = item
        // $rootScope.slot_based = item.slot_based;
        // $localStorage.slot_based = $rootScope.slot_based;
        $scope.showbook = true;
        $localStorage.selectedslot = $rootScope.selectedslot;
        
   }


   $scope.selectedtimeslot  = function(item, index)
   {
        for(var i=0;i<$scope.availableslots.length;i++)
        {
            $scope.availableslots[i].class="";
            if($scope.availableslots[i] == item)
            {
                $scope.availableslots[i].class="green";
            }
        }
        $scope.selectedslot = item;
        $rootScope.selectedslot = item
        $rootScope.slot_based = item.slot_based;
        $localStorage.slot_based = $rootScope.slot_based;
        $scope.showbook = true;
        $localStorage.selectedslot = $rootScope.selectedslot;
        
   }


   $scope.saveUserInfo = function()
   {
     var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        var reg1 = /^([0|\+[0-9]{1,5})?([1-9][0-9]{9})$/;
        var reg2 = /^[a-zA-Z\s]*$/;
         if ( ( $scope.username != undefined ) && ( reg2.test( $scope.username ) ) && $scope.useremail != undefined && $scope.useremail.length != 4 && reg.test( $scope.useremail )  && $scope.usermobile != undefined && $scope.usermobile.toString().length == 10 && reg1.test( $scope.usermobile )) {

            $scope.mobileerror = false;
                $scope.emailerror = false;
                $scope.nameerror = false;
                $rootScope.username = $scope.username;
                $rootScope.usermobile = $scope.usermobile;
                $rootScope.useremail = $scope.useremail;
                $localStorage.username = $rootScope.username;
        $localStorage.useremail = $rootScope.useremail;
        $localStorage.usermobile = $rootScope.usermobile;
         var data = CommonService.createTicket($scope);
        data.then(function (dt) {
             // $location.path("/Checkout");
             if($scope.profileListing.data.payment_type ==1)
              {$scope.askSlot = false;
                            $scope.showuserinfo = false;
                       $scope.askPlan = true;}
              else
              {
                // $location.path("/Request");
                $window.location.href ="booking.html?booking_id=";
              }

        });
               

         }
              else { 
                if(!(( $scope.username != undefined ) && ( reg2.test( $scope.username ) )))
                   {
                       $scope.nameerror = true;
                   }
                   if(!($scope.useremail != undefined && $scope.useremail.length != 4 && reg.test( $scope.useremail )))
                   {
                       $scope.emailerror = true;
                   }
                   if(!($scope.usermobile != undefined && $scope.usermobile.toString().length == 10 && reg1.test( $scope.usermobile )))
                   {
                       $scope.mobileerror = true;
                   }
            }
   }


   $scope.bookslot = function()
   {
    var flag = 0;
    if($scope.availableslotsdata.length >0)
    {
      if($scope.selectedslottemp == undefined)
      {
        $scope.errorslotbook = true;
        flag = 1;
      }
      else{
        var slot = $scope.selectedslottemp.slot_name;
      }

    }
    else{
      var slot = "";
    }
    
       if(flag ==0)
       {
          $rootScope.service_name = $scope.profileListing.data.service_name;
        // $localStorage.package_id = $rootScope.package_id;
        $localStorage.service_name = $rootScope.service_name;
        $scope.showslotspop = false;
    // $scope.showuserinfo = true;
        // $location.path("/Checkout");
        $window.location.href = "checkout.html?provider_id=" + $rootScope.provider_id + "&sub_type=" + btoa($rootScope.sub_type) + "&back=" + btoa($scope.cashback) + "&commission=" + btoa($scope.commission)  + "&convenience=" + btoa($scope.convenience_fees)  + "&discount=" + btoa($scope.discount) + "&price=" + btoa($scope.price) + "&slot_based=" + btoa(slot)  + "&provider_num=" + btoa($rootScope.providerNumber)  + "&date=" + btoa($rootScope.selecteddateval) + "&service_type=" + btoa($rootScope.service_type) + "&service_name=" + btoa($scope.profileListing.data.name) + "&sport_id=" + btoa($rootScope.sport_id) + "&locality=" + btoa($rootScope.locality) + "&selecteddayval=" + btoa($rootScope.selecteddayval)   + "&package_id=" + $scope.packageid1 + "&package_name=" + btoa($scope.buyitem.package_name) + "&partner=" + btoa($scope.profileListing.data.payment_type) + "&provider=" + btoa($scope.providern) + "&service=" + btoa($scope.servicen) + "&servicid=" + btoa($rootScope.service_id) ;
 
       }
        
        
    
   }

   $scope.bookedslotsfn = function(item)
   {
    $scope.snackbarshow = true;
     $timeout(function () {
            $scope.snackbarshow = false;
        }, 3000);
   }


 }]);

app.directive('focusMe', ['$timeout', '$parse', function($timeout, $parse) {
    return {
        link: function(scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function(value) {
                console.log('value=', value);
                if (value === !0) {
                    $timeout(function() {
                        element[0].focus()
                    })
                }
            });
            element.bind('blur', function() {
                console.log('blur');
                scope.$apply(model.assign(scope, !1))
            })
        }
    }
}]);
app.directive('whatsApp', function() {
    return {
        link: function(scope, elem, $attr) {
            elem.on('click', function() {
                var text = $attr.text;
                var url = $attr.whatsApp;
                var message = encodeURIComponent(text) + "  " + encodeURIComponent(url);
                var whatsapp_url = "whatsapp://send?text=" + message;
                window.location.href = whatsapp_url
            })
        }
    }
})