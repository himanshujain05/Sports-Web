var app = angular.module('App', ['ngRoute', 'ngStorage', 'ngMap', 'angular-md5']);
app.constant('globals', {
    mainPage: 'https://sportido.com'
});
        app.controller('SportidoApp', ["$scope", "CommonService", "$location", "$rootScope", "$localStorage", "$window", '$interval',
 function ($scope, CommonService, $location, $rootScope, $localStorage, $window, $interval) {

  $rootScope.whatsappShare = function() {
        $rootScope.currentpage = $location.absUrl();
        $scope.sharewhatsappurl = "whatsapp://send?text=" + currentpage
    }
    $scope.init = function()
    {
      $scope.showit = true;
      $scope.shareUrl = $location.absUrl();
      $scope.showsportspop = false;
        $scope.test = "Hi Sportido";
                new Fingerprint2().get(function(result, components){
  console.log(result); 
  console.log(components); 
  clevertap.profile.push({
 "Site": {
   "PlayerID": 42, // User's name
   "UID": result
 }


});
  $rootScope.UID = result;
   clevertap.event.push("Product Viewed");
});
        // $scope.localvalue();
        var currentpage = $location.absUrl();
      $window.scrollTo(0, 0);
      $rootScope.breadid = 1;
      $scope.userconntected = true;
        $scope.test = "Hi Sportido";
        $scope.hh = 40;
        $scope.mm = 0;
        $scope.sec = 0;
        $scope.thh = 40;
         $scope.tmm = 0;
        $scope.tsec = 0;
        $rootScope.player_id =  42;
                $rootScope.walletAmount = 0;
                $localStorage.walletAmount = 0;
                $localStorage.player_id = 42;
                // $scope.sportList();

    $interval(function () {
             if($scope.tmm ==0)
             {
              $scope.thh = $scope.thh - 1;
             }
             if($scope.tsec == 0)
             {
                if($scope.tmm ==0)
                 {
                  $scope.tmm = 59;
                 }
                 else{
                  $scope.tmm = $scope.tmm -1;
                 }
             }

             
             if($scope.tsec ==0)
             {
              $scope.tsec = 59;
             }
             else{
              $scope.tsec = $scope.tsec -1;
             }

             

             

             $scope.hh = $scope.thh;
            $scope.mm = $scope.tmm;
            $scope.sec = $scope.tsec;


           
         }, 1000);


        // $scope.sportslisting = {"data": [{"subtype": "Cricket Academy", "min_cost": 600, "sport_id": 26, "subtype_image": "subtype/CricketAcademy.jpg"}, {"subtype": "Cricket Ground", "min_cost": 650, "sport_id": 26, "subtype_image": "subtype/CricketGround.jpg"}, {"subtype": "Cricket Pitch", "min_cost": 200, "sport_id": 26, "subtype_image": "subtype/CricketPitch.jpg"}, {"subtype": "Cricket Coach", "min_cost": 1000, "sport_id": 26, "subtype_image": "subtype/CricketCoach.jpg"}, {"subtype": "Gully Cricket", "min_cost": 1000, "sport_id": 26, "subtype_image": "subtype/GullyCricket.jpg"}, {"subtype": "Football Ground", "min_cost": 300, "sport_id": 46, "subtype_image": "subtype/FootballGround.jpg"}, {"subtype": "Football Academy", "min_cost": 500, "sport_id": 46, "subtype_image": "subtype/FootballAcademy.jpg"}, {"subtype": "Football Coach", "min_cost": 1200, "sport_id": 46, "subtype_image": "subtype/FootballCoach.jpg"}, {"subtype": "Football Beach Ground", "min_cost": 1000, "sport_id": 46, "subtype_image": "subtype/FootballBeachGround.jpg"}, {"subtype": "Bungee Jumping", "min_cost": 3500, "sport_id": 18, "subtype_image": "subtype/BungeeJumping.jpg"}, {"subtype": "Gym", "min_cost": 80, "sport_id": 63, "subtype_image": "subtype/Gym.jpg"}, {"subtype": "Fitness Activity", "min_cost": 80, "sport_id": 63, "subtype_image": "subtype/FitnessActivity.jpg"}, {"subtype": "Fitness Trainer", "min_cost": 500, "sport_id": 63, "subtype_image": "subtype/FitnessTrainer.jpg"}, {"subtype": "Volleyball Academy", "min_cost": 400, "sport_id": 432, "subtype_image": "subtype/VolleyballAcademy.jpg"}, {"subtype": "Volleyball Court", "min_cost": 500, "sport_id": 432, "subtype_image": "subtype/VolleyballCourt.jpg"}, {"subtype": "Dance Classes", "min_cost": 150, "sport_id": 33, "subtype_image": "subtype/DanceClasses.jpg"}, {"subtype": "Dance Academy", "min_cost": 500, "sport_id": 33, "subtype_image": "subtype/DanceAcademy.jpg"}, {"subtype": "Contemporary Dance Academy", "min_cost": 1200, "sport_id": 33, "subtype_image": "subtype/ContemporaryDanceAcademy.jpg"}, {"subtype": "Bollywood Dance Academy", "min_cost": 1000, "sport_id": 33, "subtype_image": "subtype/BollywoodDanceAcademy.jpg"}, {"subtype": "Hip Hop Dance Academy", "min_cost": 1200, "sport_id": 33, "subtype_image": "subtype/HipHopDanceAcademy.jpg"}, {"subtype": "Jazz Dance Academy", "min_cost": 1700, "sport_id": 33, "subtype_image": "subtype/JazzDanceAcademy.jpg"}, {"subtype": "Salsa Dance Academy", "min_cost": 1500, "sport_id": 33, "subtype_image": "subtype/SalsaDanceAcademy.jpg"}, {"subtype": "Ballet Dance Academy", "min_cost": 2000, "sport_id": 33, "subtype_image": "subtype/BalletDanceAcademy.jpg"}, {"subtype": "Classical Dance Academy", "min_cost": 2500, "sport_id": 33, "subtype_image": "subtype/ClassicalDanceAcademy.jpg"}, {"subtype": "Kathak Dance Academy", "min_cost": 1400, "sport_id": 33, "subtype_image": "subtype/KathakDanceAcademy.jpg"}, {"subtype": "Western Dance Academy", "min_cost": 1200, "sport_id": 33, "subtype_image": "subtype/WesternDanceAcademy.jpg"}, {"subtype": "Dance Coach", "min_cost": 500, "sport_id": 33, "subtype_image": "subtype/DanceCoach.jpg"}, {"subtype": "Hockey Academy", "min_cost": 300, "sport_id": 72, "subtype_image": "subtype/HockeyAcademy.jpg"}, {"subtype": "Hockey Field", "min_cost": 50, "sport_id": 72, "subtype_image": "subtype/HockeyField.jpg"}, {"subtype": "Swimming Academy", "min_cost": 300, "sport_id": 379, "subtype_image": "subtype/SwimmingAcademy.jpg"}, {"subtype": "Swimming Pool", "min_cost": 100, "sport_id": 379, "subtype_image": "subtype/SwimmingPool.jpg"}, {"subtype": "Badminton Academy", "min_cost": 750, "sport_id": 4, "subtype_image": "subtype/BadmintonAcademy.jpg"}, {"subtype": "Badminton Court", "min_cost": 68, "sport_id": 4, "subtype_image": "subtype/BadmintonCourt.jpg"}, {"subtype": "Yoga Academy", "min_cost": 100, "sport_id": 501, "subtype_image": "subtype/YogaAcademy.jpg"}, {"subtype": "Yoga Coach", "min_cost": 600, "sport_id": 501, "subtype_image": "subtype/YogaCoach.jpg"}, {"subtype": "Basketball Academy", "min_cost": 600, "sport_id": 9, "subtype_image": "subtype/BasketballAcademy.jpg"}, {"subtype": "Basketball Court", "min_cost": 50, "sport_id": 9, "subtype_image": "subtype/BasketballCourt.jpg"}, {"subtype": "Basketball Coach", "min_cost": 900, "sport_id": 9, "subtype_image": "subtype/BasketballCoach.jpg"}, {"subtype": "Table Tennis Academy", "min_cost": 800, "sport_id": 380, "subtype_image": "subtype/TableTennisAcademy.jpg"}, {"subtype": "Table Tennis Table", "min_cost": 58, "sport_id": 380, "subtype_image": "subtype/TableTennisTable.jpg"}, {"subtype": "Table Tennis Coach", "min_cost": 300, "sport_id": 380, "subtype_image": "subtype/TableTennisCoach.jpg"}, {"subtype": "Jogging Track", "min_cost": 50, "sport_id": 81, "subtype_image": "subtype/JoggingTrack.jpg"}, {"subtype": "Billiards Table", "min_cost": 60, "sport_id": 10, "subtype_image": "subtype/BilliardsTable.jpg"}, {"subtype": "Billiards Coaching", "min_cost": 2000, "sport_id": 10, "subtype_image": "subtype/BilliardsCoaching.jpg"}, {"subtype": "Bowling Alley", "min_cost": 170, "sport_id": 15, "subtype_image": "subtype/BowlingAlley.jpg"}, {"subtype": "Krav Maga Academy", "min_cost": 1800, "sport_id": 86, "subtype_image": "subtype/KravMagaAcademy.jpg"}, {"subtype": "Lawn Tennis Academy", "min_cost": 700, "sport_id": 105, "subtype_image": "subtype/LawnTennisAcademy.jpg"}, {"subtype": "Lawn Tennis Court", "min_cost": 75, "sport_id": 105, "subtype_image": "subtype/LawnTennisCourt.jpg"}, {"subtype": "Lawn Tennis Coach", "min_cost": 1750, "sport_id": 105, "subtype_image": "subtype/LawnTennisCoach.jpg"}, {"subtype": "Mini Football Academy", "min_cost": 1200, "sport_id": 121, "subtype_image": "subtype/MiniFootballAcademy.jpg"}, {"subtype": "Squash Academy", "min_cost": 2000, "sport_id": 358, "subtype_image": "subtype/SquashAcademy.jpg"}, {"subtype": "Squash Court", "min_cost": 58, "sport_id": 358, "subtype_image": "subtype/SquashCourt.jpg"}, {"subtype": "Squash Coach", "min_cost": 2000, "sport_id": 358, "subtype_image": "subtype/SquashCoach.jpg"}, {"subtype": "Aerobics Academy", "min_cost": 100, "sport_id": 1, "subtype_image": "subtype/AerobicsAcademy.jpg"}, {"subtype": "Chess Academy", "min_cost": 1500, "sport_id": 23, "subtype_image": "subtype/ChessAcademy.jpg"}, {"subtype": "Kickboxing Classes", "min_cost": 1000, "sport_id": 97, "subtype_image": "subtype/KickboxingClasses.jpg"}, {"subtype": "Kickboxing Academy", "min_cost": 500, "sport_id": 97, "subtype_image": "subtype/KickboxingAcademy.jpg"}, {"subtype": "Snooker Table", "min_cost": 60, "sport_id": 314, "subtype_image": "subtype/SnookerTable.jpg"}, {"subtype": "Snooker Academy", "min_cost": 200, "sport_id": 314, "subtype_image": "subtype/SnookerAcademy.jpg"}, {"subtype": "Zumba Academy", "min_cost": 100, "sport_id": 504, "subtype_image": "subtype/ZumbaAcademy.jpg"}, {"subtype": "Go Karting Tracks", "min_cost": 350, "sport_id": 57, "subtype_image": "subtype/GoKartingTracks.jpg"}, {"subtype": "Pilates Classes", "min_cost": 250, "sport_id": 179, "subtype_image": "subtype/PilatesClasses.jpg"}, {"subtype": "Pool Table", "min_cost": 60, "sport_id": 186, "subtype_image": "subtype/PoolTable.jpg"}, {"subtype": "Pool Academy", "min_cost": 100, "sport_id": 186, "subtype_image": "subtype/PoolAcademy.jpg"}, {"subtype": "Pool Table", "min_cost": 60, "sport_id": 186, "subtype_image": "subtype/SnookerTable.jpg"}, {"subtype": "Archery Academy", "min_cost": 600, "sport_id": 2, "subtype_image": "subtype/ArcheryAcademy.jpg"}, {"subtype": "Archery Range", "min_cost": 500, "sport_id": 2, "subtype_image": "subtype/ArcheryRange.jpg"}, {"subtype": "Ice Skating Arena", "min_cost": 600, "sport_id": 37, "subtype_image": "subtype/IceSkatingArena.jpg"}, {"subtype": "Sky Diving", "min_cost": 35000, "sport_id": 42, "subtype_image": "subtype/SkyDiving.jpg"}, {"subtype": "Golf Academy", "min_cost": 550, "sport_id": 58, "subtype_image": "subtype/GolfAcademy.jpg"}, {"subtype": "Golf Course", "min_cost": 50, "sport_id": 58, "subtype_image": "subtype/GolfCourse.jpg"}, {"subtype": "Golf Coach", "min_cost": 6500, "sport_id": 58, "subtype_image": "subtype/GolfCoach.jpg"}, {"subtype": "Shooting Academy", "min_cost": 2000, "sport_id": 279, "subtype_image": "subtype/ShootingAcademy.jpg"}, {"subtype": "Shooting Range", "min_cost": 250, "sport_id": 279, "subtype_image": "subtype/ShootingRange.jpg"}, {"subtype": "Zipline Adventure Sports", "min_cost": 1650, "sport_id": 514, "subtype_image": "subtype/ZiplineAdventureSports.jpg"}, {"subtype": "Paragliding", "min_cost": 2500, "sport_id": 170, "subtype_image": "subtype/Paragliding.jpg"}, {"subtype": "Trekking", "min_cost": 500, "sport_id": 507, "subtype_image": "subtype/Trekking.jpg"}, {"subtype": "Hot Air Balloon", "min_cost": 10000, "sport_id": 508, "subtype_image": "subtype/HotAirBalloon.jpg"}, {"subtype": "Baseball Academy", "min_cost": 670, "sport_id": 8, "subtype_image": "subtype/BaseballAcademy.jpg"}, {"subtype": "Baseball Court", "min_cost": 10000, "sport_id": 8, "subtype_image": "subtype/BaseballCourt.jpg"}, {"subtype": "Boxing Academy", "min_cost": 800, "sport_id": 16, "subtype_image": "subtype/BoxingAcademy.jpg"}, {"subtype": "Laser Tag Arena", "min_cost": 1150, "sport_id": 505, "subtype_image": "subtype/LaserTagArena.jpg"}, {"subtype": "Crossfit", "min_cost": 4500, "sport_id": 520, "subtype_image": "subtype/Crossfit.jpg"}, {"subtype": "Paramotring", "min_cost": 1500, "sport_id": 523, "subtype_image": "subtype/Paramotring.jpg"}, {"subtype": "ATV Ride", "min_cost": 400, "sport_id": 525, "subtype_image": "subtype/ATVRide.jpg"}, {"subtype": "Judo Academy", "min_cost": 800, "sport_id": 82, "subtype_image": "subtype/JudoAcademy.jpg"}, {"subtype": "Karate Academy", "min_cost": 500, "sport_id": 85, "subtype_image": "subtype/KarateAcademy.jpg"}, {"subtype": "Mixed Martial Arts Academy", "min_cost": 500, "sport_id": 123, "subtype_image": "subtype/MixedMartialArtsAcademy.jpg"}, {"subtype": "Paintball Arena", "min_cost": 250, "sport_id": 167, "subtype_image": "subtype/PaintballArena.jpg"}, {"subtype": "River Rafting", "min_cost": 600, "sport_id": 196, "subtype_image": "subtype/RiverRafting.jpg"}, {"subtype": "Roller Skating Academy", "min_cost": 500, "sport_id": 225, "subtype_image": "subtype/RollerSkatingAcademy.jpg"}, {"subtype": "Roller Skating Rink", "min_cost": 10, "sport_id": 225, "subtype_image": "subtype/RollerSkatingRink.jpg"}, {"subtype": "Taekwondo Academy", "min_cost": 406, "sport_id": 382, "subtype_image": "subtype/TaekwondoAcademy.jpg"}, {"subtype": "Rappelling", "min_cost": 1650, "sport_id": 509, "subtype_image": "subtype/Rappelling.jpg"}, {"subtype": "Gymnastic Academy", "min_cost": 800, "sport_id": 511, "subtype_image": "subtype/GymnasticAcademy.jpg"}, {"subtype": "Kung Fu Academy", "min_cost": 3500, "sport_id": 512, "subtype_image": "subtype/KungFuAcademy.jpg"}, {"subtype": "Foosball", "min_cost": 160, "sport_id": 519, "subtype_image": "subtype/Foosball.jpg"}, {"subtype": "Giant Swing", "min_cost": 3500, "sport_id": 521, "subtype_image": "subtype/GiantSwing.jpg"}, {"subtype": "Flying Fox", "min_cost": 1700, "sport_id": 522, "subtype_image": "subtype/FlyingFox.jpg"}, {"subtype": "Off Roading", "min_cost": 500, "sport_id": 524, "subtype_image": "subtype/OffRoading.jpg"}, {"subtype": "Camping", "min_cost": 1500, "sport_id": 19, "subtype_image": "subtype/Camping.jpg"}, {"subtype": "Horse Riding Academy", "min_cost": 300, "sport_id": 73, "subtype_image": "subtype/HorseRidingAcademy.jpg"}, {"subtype": "Air Hockey", "min_cost": 160, "sport_id": 131, "subtype_image": "subtype/AirHockey.jpg"}, {"subtype": "Rock Climbing", "min_cost": 1800, "sport_id": 224, "subtype_image": "subtype/RockClimbing.jpg"}, {"subtype": "Rugby Coach", "min_cost": 500, "sport_id": 233, "subtype_image": "subtype/RugbyCoach.jpg"}], "success": 1};
       
    }

    $scope.showsportspopfn = function()
    {
      $scope.showsportspop = false;
    }

    $scope.selectedSports = function(item)
   {
        $scope.selectedSportsMdl = item;
        $scope.activityinput = item.subtype;
        $rootScope.sport_id = item.sport_id;
        $localStorage.sport_id = $rootScope.sport_id;
        $rootScope.sub_type = item.subtype;
//         clevertap.event.push("Clicked_service_search", {
//   "Service_name":item.subtype,
// });
        
        $localStorage.sub_type = $rootScope.sub_type;
        $rootScope.searchsport = $scope.searchsport;
        $localStorage.searchsport = $scope.searchsport;
        // $location.path("/Listing");
         $window.location.href = "listing.html?sub_type=" + btoa($rootScope.sub_type);
        // location.href='listing.html?&sport_id=' + item.sport_id + '&sub_type=' + item.subtype;
   }

    // Define user empty data :/
      $scope.user = {};
      
      // Defining user logged status
      $scope.logged = false;
      
      // And some fancy flags to display messages upon user status change
      $scope.byebye = false;
      $scope.salutation = false;
      
      /**
       * Watch for Facebook to be ready.
       * There's also the event that could be used
       */
      // $scope.$watch(
      //   function() {
      //     return Facebook.isReady();
      //   },
      //   function(newVal) {
      //     if (newVal)
      //       $scope.facebookReady = true;
      //   }
      // );
      
      var userIsConnected = false;
      
      // Facebook.getLoginStatus(function(response) {
      //   if (response.status == 'connected') {
      //     userIsConnected = true;
      //     $scope.userconntected = true;
      //     $scope.me();
      //   }
      //   else{
      //     $scope.userconntected = false;
      //     $scope.login();
      //   }
      // });
      
      /**
       * IntentLogin
       */
      // $scope.IntentLogin = function() {
      //   if(!userIsConnected) {
      //     $scope.login();
      //   }
      // };
      
      /**
       * Login
       */
       // $scope.login = function() {
       //   Facebook.login(function(response) {
       //    if (response.status == 'connected') {
       //      $scope.logged = true;
       //      $scope.userconntected = true;
       //      $scope.me();
       //    }
        
       //  });
       // };
       
       /**
        * me 
        */
 //        $scope.me = function() {
 //          Facebook.api('/me?fields=email,name,id,gender,location,age_range,locale', function(response) {
 //            /**
 //             * Using $scope.$apply since this happens outside angular framework.
 //             */
 //            $scope.$apply(function() {
 //              $scope.user = response;
 //              $rootScope.username = response.name;
 //              $rootScope.useremail = response.email;
 //              $rootScope.fbid = response.id;
 //              $rootScope.gender = response.gender;
 //              $rootScope.userlocation = response.location;
 //              $localStorage.username = $rootScope.username;
 //              $localStorage.useremail = $rootScope.useremail;
 //              $localStorage.fbid = $rootScope.fbid;
 //              $localStorage.gender = $rootScope.gender;
 //              $localStorage.userlocation = $rootScope.userlocation;
 //               var data = CommonService.signUp($scope);
 //                data.then(function (dt) {
 //                console.log(dt);
 //                $scope.signupdetails = dt.data;
 //                $rootScope.player_id =  $scope.signupdetails.data.player_id;
 //                $rootScope.walletAmount = $scope.signupdetails.data.wallet_balance;
 //                $localStorage.walletAmount = $rootScope.walletAmount;
 //                $localStorage.player_id = $rootScope.player_id;
 //                clevertap.profile.push({
 // "Site": {
 //   "PlayerID": $rootScope.player_id, // User's name
 //   "UID": $rootScope.UID,
 // }
 //        });
 //                $scope.sportList();
                 
 //        });
 //            });
            
 //          });
 //        };
      
      /**
       * Logout
       */

       $scope.sportList = function()
       {
        if($scope.sportslistFlag != true)
        {
          var data = CommonService.getSportsapi($scope);
                         data.then(function (dt) {
                         console.log(dt);
                         $scope.sportslisting = dt.data;
                         $scope.sportslistFlag = true;
        
                });
                       }
       }
      // $scope.logout = function() {
      //   Facebook.logout(function() {
      //     $scope.$apply(function() {
      //       $scope.user   = {};
      //       $scope.logged = false;  
      //     });
      //   });
      // }

      $rootScope.GetDates = function(startDate, daysToAdd) {
        var aryDates = [];
        for (var i = 0; i <= daysToAdd; i++) {
            var currentDate = new Date();
            currentDate.setDate(startDate.getDate() + i);
            aryDates.push($rootScope.DayAsString(currentDate.getDay()) + ", " + currentDate.getDate() + ", " + currentDate.getFullYear() + "-" + (currentDate.getMonth() + 1) + "-" + currentDate.getDate())
        }
        return aryDates
    }
    $rootScope.MonthAsString = function(monthIndex) {
        var d = new Date();
        var month = new Array();
        month[0] = "January";
        month[1] = "February";
        month[2] = "March";
        month[3] = "April";
        month[4] = "May";
        month[5] = "June";
        month[6] = "July";
        month[7] = "August";
        month[8] = "September";
        month[9] = "October";
        month[10] = "November";
        month[11] = "December";
        return month[monthIndex]
    }
    $rootScope.DayAsString = function(dayIndex) {
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        return weekdays[dayIndex]
    }
       $scope.viewMore = function(item, subtype, id, id1, type)
   {
    $rootScope.provider_id = item;
    $localStorage.provider_id = $rootScope.provider_id;
    $rootScope.sub_type = subtype;
    $localStorage.sub_type = subtype;
    $rootScope.sport_id = id;
        $localStorage.sport_id = $rootScope.sport_id;
    $rootScope.breadid = 2;
     clevertap.event.push("Clicked_service_top3", {
  "Service_name":subtype,
});
   $window.location.href = "profile.html?provider_id=" + $rootScope.provider_id + "&sub_type=" + btoa($rootScope.sub_type) + "&service_id=" + btoa(id1) + "&provider=" + btoa(type) + "&service=" + btoa(subtype);
      // location.href='profile.html?&sport_id=' + $scope.sport_id + '&sub_type=' + $scope.sub_type + '&provider_id=' + item.provider_id;
   }

     // $scope.$on('Facebook:statusChange', function(ev, data) {
     //    console.log('Status: ', data);
     //    if (data.status == 'connected') {
     //      $scope.$apply(function() {
     //        $scope.salutation = true;
     //        $scope.byebye     = false;    
     //      });
     //    } else {
     //      $scope.$apply(function() {
     //        $scope.salutation = false;
     //        $scope.byebye     = true;
            
     //        // Dismiss byebye message after two seconds
     //        $timeout(function() {
     //          $scope.byebye = false;
     //        }, 2000)
     //      });
     //    }
        
        
     //  });


 }]);

app.directive('focusMe', ['$timeout', '$parse', function($timeout, $parse) {
    return {
        link: function(scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function(value) {
                console.log('value=', value);
                if (value === !0) {
                    $timeout(function() {
                        element[0].focus()
                    })
                }
            });
            element.bind('blur', function() {
                console.log('blur');
                scope.$apply(model.assign(scope, !1))
            })
        }
    }
}]);
app.directive('whatsApp', function() {
    return {
        link: function(scope, elem, $attr) {
            elem.on('click', function() {
                var text = $attr.text;
                var url = $attr.whatsApp;
                var message = encodeURIComponent(text) + "  " + encodeURIComponent(url);
                var whatsapp_url = "whatsapp://send?text=" + message;
                window.location.href = whatsapp_url
            })
        }
    }
})