var app = angular.module('App', ['ngRoute', 'ngStorage', 'ngMap', 'angular-md5']);
app.constant('globals', {
    mainPage: 'https://sportido.com'
});
        app.controller('SportidoThanks', ["$scope", "CommonService", "$location", "$timeout", "$rootScope", "$localStorage", "$window",
 function ($scope, CommonService,$location,$timeout, $rootScope, $localStorage, $window) {

  // $scope.usermobile = 8124438581;
  $rootScope.whatsappShare = function() {
        $rootScope.currentpage = $location.absUrl();
        $scope.sharewhatsappurl = "whatsapp://send?text=" + currentpage
    }
    $scope.init = function()
    {
        $scope.showThanks = false;
        $scope.shareUrl = $location.absUrl();
         var temp = $location.absUrl().split('#')[0].split('?');
         if (temp.length == 2) {
            var temp1 = temp[1].split('&');
             for (var i = 0; i < temp1.length; i++) {
              if (temp1[i].indexOf("booking_id") != -1) {
                 $rootScope.booking_id = temp1[i].split('=')[1];
                 $rootScope.payout = {};
                 $rootScope.payout.booking_id = $rootScope.booking_id;
                  $scope.showThanks = true;
            $scope.showBtn = true;
             }
             else if (temp1[i].indexOf("message") != -1) {
                 $rootScope.message = temp1[i].split('=')[1];
                 }
            else if (temp1[i].indexOf("mode") != -1) {
                 $scope.mode = atob(temp1[i].split('=')[1]);
                 }
             else if (temp1[i].indexOf("txn_status") != -1) {
                 $rootScope.txn_status = temp1[i].split('=')[1];
                 if($rootScope.txn_status == '0300')
                 {
                     $scope.successFlag = true;
                 }
                 else if($rootScope.txn_status == '0392' || $rootScope.txn_status == '0399' || $rootScope.txn_status == '0397' || $rootScope.txn_status == '0395'){
                    $scope.showBtn = true;
                    $scope.showoops1 = true;
                    $scope.showRetry = true;
                   
                 }
                 else{
                    $scope.showBtn = true;
                     $scope.showoops = true;
                 }
             }
             
            else if (temp1[i].indexOf("tpsl_txn_id") != -1) {
                 $rootScope.tpsl_txn_id = temp1[i].split('=')[1];
             }
            }
            
            
         }
         else{
            $scope.showThanks = true;
            $scope.showBtn = true;
         }

         if($scope.successFlag == true)
         {
                // $rootScope.payout = $localStorage.payout;
                            $scope.showThanks = true;
                            $scope.showBtn = true;
         }
    }


     
     $scope.redirect = function(id)
     {
        if(id == 1)
        {
            $window.location.href = "https://sportido.app.link/appstore";
        }
        else  if(id == 1)
        {
             $window.location.href = "https://sportido.app.link/playstore";
        }
     }
  
    $scope.goHome = function()
    {
        $window.location.href ="home.html";
    }

     $scope.Retry = function()
    {
         var configJson =$localStorage.configJson;

                $.pnCheckout(configJson);
                if(configJson.features.enableNewWindowFlow){
                    $(document).data('pnCheckout').openNewWindow();
                }
    }
   
    
  

 }]);

app.directive('focusMe', ['$timeout', '$parse', function($timeout, $parse) {
    return {
        link: function(scope, element, attrs) {
            var model = $parse(attrs.focusMe);
            scope.$watch(model, function(value) {
                console.log('value=', value);
                if (value === !0) {
                    $timeout(function() {
                        element[0].focus()
                    })
                }
            });
            element.bind('blur', function() {
                console.log('blur');
                scope.$apply(model.assign(scope, !1))
            })
        }
    }
}]);
app.directive('whatsApp', function() {
    return {
        link: function(scope, elem, $attr) {
            elem.on('click', function() {
                var text = $attr.text;
                var url = $attr.whatsApp;
                var message = encodeURIComponent(text) + "  " + encodeURIComponent(url);
                var whatsapp_url = "whatsapp://send?text=" + message;
                window.location.href = whatsapp_url
            })
        }
    }
})